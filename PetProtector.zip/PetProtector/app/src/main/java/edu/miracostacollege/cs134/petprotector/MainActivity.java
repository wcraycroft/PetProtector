package edu.miracostacollege.cs134.petprotector;

import android.Manifest;
import android.app.Activity;
import android.content.ContentResolver;
import android.content.Context;
import android.content.pm.PackageManager;
import android.content.res.Resources;
import android.net.Uri;
import android.os.Bundle;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.ImageView;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        ImageView petImageView = findViewById(R.id.petImageView);
        petImageView.setImageURI(getUriToResource(this, R.drawable.none));
    }

    private static Uri getUriToResource(Context context, int id) {
        Resources res = context.getResources();
        String uri = ContentResolver.SCHEME_ANDROID_RESOURCE + "://"
                + res.getResourcePackageName(id) + "/"
                + res.getResourceTypeName(id) + "/"
                + res.getResourceEntryName(id);

        return Uri.parse(uri);
    }

    public void selectPetImage(View v) {
        // Make a list (empty) of permissions
        // As user grants them, add each permission to the list
        List<String> permsList = new ArrayList<>();
        //List<String> requiredPerms = new ArrayList<>();

        //requiredPerms.add(Manifest.permission.CAMERA);
        //requiredPerms.add(Manifest.permission.WRITE_EXTERNAL_STORAGE);
        //requiredPerms.add(Manifest.permission.READ_EXTERNAL_STORAGE);

        int permReqCode = 100;
        int hasCameraPerm = ContextCompat.checkSelfPermission(this,
                Manifest.permission.CAMERA);
        int hasReadExternalPerm = ContextCompat.checkSelfPermission(this,
                Manifest.permission.READ_EXTERNAL_STORAGE);
        int hasWriteExternalPerm = ContextCompat.checkSelfPermission(this,
                Manifest.permission.WRITE_EXTERNAL_STORAGE);

        // If denied, add it to List of permission requests
        // Camera
        if (hasCameraPerm == PackageManager.PERMISSION_DENIED)
            permsList.add(Manifest.permission.CAMERA);
        // Read External File
        if (hasReadExternalPerm == PackageManager.PERMISSION_DENIED)
            permsList.add(Manifest.permission.READ_EXTERNAL_STORAGE);
        // Write External File
        if (hasWriteExternalPerm == PackageManager.PERMISSION_DENIED)
            permsList.add(Manifest.permission.WRITE_EXTERNAL_STORAGE);

        // Ask user for for permissions
        if (permsList.size() > 0) {
            // Convert List into array
            String[] perms = new String[permsList.size()];
            permsList.toArray(perms);
            // Make the request to the user (backwards compatible
            ActivityCompat.requestPermissions(this, perms, permReqCode);
        }

    }

    /*private List<String> getPermsList(List<String> requiredPermissions) {

        List<String> permsList = new ArrayList<>();
        int i = 0;
        while (requiredPermissions.size() > 0) {
            String perm = requiredPermissions.remove(i++);
            int hasPerm = ContextCompat.checkSelfPermission(this, perm);
        }

        // If denied, add it to List of permission requests
        // Camera
        if (hasCameraPerm == PackageManager.PERMISSION_DENIED)
            permsList.add(Manifest.permission.CAMERA);
        // Read External File
        if (hasReadExternalPerm == PackageManager.PERMISSION_DENIED)
            permsList.add(Manifest.permission.READ_EXTERNAL_STORAGE);
        // Write External File
        if (hasWriteExternalPerm == PackageManager.PERMISSION_DENIED)
            permsList.add(Manifest.permission.WRITE_EXTERNAL_STORAGE);

    }
    */

}
